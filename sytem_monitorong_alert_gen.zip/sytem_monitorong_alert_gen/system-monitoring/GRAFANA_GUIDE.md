# Grafana Integration Guide

## 1. Connect PostgreSQL to Grafana
1.  Open Grafana (usually `http://localhost:3000`).
2.  Go to **Configuration (Gear Icon) -> Data Sources**.
3.  Click **Add data source**.
4.  Search for **PostgreSQL** and select it.
5.  **Settings**:
    -   **Host**: `localhost:5432`
    -   **Database**: `system_monitoring`
    -   **User**: `postgres`
    -   **Password**: `password`
    -   **SSL Mode**: `disable` (for local dev)
6.  Click **Save & Test**. You should see "Database Connection OK".

## 2. Create a Dashboard
1.  Click **Create (+) -> Dashboard**.
2.  Click **Add a new panel**.

## 3. Example Queries (SQL)

### CPU Usage Over Time (Graph Panel)
```sql
SELECT
  timestamp AS "time",
  cpu_usage AS "CPU"
FROM metrics
ORDER BY timestamp
```

### Memory Usage (Gauge Panel)
Query for the latest value:
```sql
SELECT
  timestamp AS "time",
  memory_usage AS "Memory"
FROM metrics
ORDER BY timestamp DESC
LIMIT 1
```

### Alert History (Table Panel)
```sql
SELECT
  timestamp,
  metric_name,
  metric_value,
  severity
FROM alerts
ORDER BY timestamp DESC
```

## 4. Tips
-   Ensure your `timestamp` column is selected as `"time"` so Grafana recognizes it.
-   Use the "Time Series" visualization for CPU/Memory history.
-   Use the "Table" visualization for the Alert logs.
