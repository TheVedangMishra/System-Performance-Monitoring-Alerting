"""
config.py

Configuration for System Monitoring with PostgreSQL.
"""

# --- Database Connection ---
DB_NAME = "system_monitoring"
DB_USER = "postgres"
DB_PASS = "password"
DB_HOST = "localhost"
DB_PORT = "5432"

# --- Alert Thresholds ---
CPU_THRESHOLD = 80.0
MEMORY_THRESHOLD = 75.0
DISK_THRESHOLD = 85.0

# --- General ---
# Collect metrics every 60 seconds (1 minute)
MONITOR_INTERVAL = 60
