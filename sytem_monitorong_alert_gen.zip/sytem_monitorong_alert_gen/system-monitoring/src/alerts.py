"""
alerts.py

Checks the database for recent metrics and generates alerts if thresholds are exceeded.
Stores alerts in the 'alerts' table.
"""

import time
import fetcher
import db
import config

def log_alert_to_db(metric_name, value, threshold):
    """
    Inserts a triggered alert into the alerts table.
    """
    conn = db.get_db_connection()
    if not conn:
        return

    try:
        cursor = conn.cursor()
        query = """
            INSERT INTO alerts (metric_name, metric_value, threshold, severity)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(query, (metric_name, value, threshold, 'HIGH'))
        conn.commit()
        print(f" >> [ALERT GENERATED] {metric_name}: {value}% > {threshold}%")
    except Exception as e:
        print(f"Error logging alert: {e}")
    finally:
        conn.close()

def check_and_alert():
    """
    Main loop to check (fetch) metrics and log (insert) alerts.
    """
    print("[*] Alert System Running (Checking DB every 60s)...")
    
    while True:
        # 1. Fetch latest data from DB
        data = fetcher.get_latest_metrics()
        
        if data:
            # 2. Check CPU
            if data['cpu'] > config.CPU_THRESHOLD:
                log_alert_to_db("CPU", data['cpu'], config.CPU_THRESHOLD)

            # 3. Check Memory
            if data['memory'] > config.MEMORY_THRESHOLD:
                log_alert_to_db("Memory", data['memory'], config.MEMORY_THRESHOLD)

            # 4. Check Disk
            if data['disk'] > config.DISK_THRESHOLD:
                log_alert_to_db("Disk", data['disk'], config.DISK_THRESHOLD)
        else:
            print("[!] No data found in metrics table yet.")

        # Wait before checking again
        time.sleep(config.MONITOR_INTERVAL)

if __name__ == "__main__":
    check_and_alert()
