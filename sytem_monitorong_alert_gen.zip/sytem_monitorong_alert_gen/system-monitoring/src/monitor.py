"""
monitor.py

This is the *Entry Point* of our application.
It uses 'psutil' to read system stats and 'alerts.py' to check them.
Run this file to start monitoring!
"""

import time     # To use sleep (pause) functions
import psutil   # To access system hardware details
import sys      # To exit the program cleanly

# Import our own custom modules
# We expect these files to be in the same folder
import config
import alerts

def get_system_metrics():
    """
    Reads the current state of the CPU, RAM, and Disk.
    Returns three values: cpu, ram, disk (percentages).
    """
    # 1. Get CPU Percent
    # interval=1 means "measure for 1 second" to get an accurate number
    cpu = psutil.cpu_percent(interval=1)
    
    # 2. Get RAM (Memory) Percent
    # .percent gives us just the number we care about (e.g., 45.3)
    ram = psutil.virtual_memory().percent
    
    # 3. Get Disk Percent
    # '/' means we check the main drive (C: on Windows, / on Linux)
    disk = psutil.disk_usage('/').percent
    
    return cpu, ram, disk

def start_monitoring():
    """
    The main loop that runs forever (until we stop it).
    """
    print("--------------------------------------------------")
    print(f"[*] Starting System Monitor...")
    print(f"[*] Config: Checking every {config.MONITOR_INTERVAL} seconds.")
    print(f"[*] Limits: CPU > {config.CPU_THRESHOLD}%, RAM > {config.MEMORY_THRESHOLD}%, DISK > {config.DISK_THRESHOLD}%")
    print("--------------------------------------------------")
    print("[*] Press Ctrl+C to stop.\n")

    try:
        # 'while True' creates an Infinite Loop
        while True:
            # --- STEP 1: COLLECT DATA ---
            # Call our helper function to get the numbers
            cpu_val, ram_val, disk_val = get_system_metrics()
            
            # --- STEP 2: CHECK FOR ALERTS ---
            # Pass the numbers to the alerts module logic
            active_alerts = alerts.check_thresholds(cpu_val, ram_val, disk_val)

            # --- STEP 3: DISPLAY METRICS ---
            # Print a clean line showing current status
            print(f"[Metrics] CPU: {cpu_val}% | RAM: {ram_val}% | Disk: {disk_val}%")

            # --- STEP 4: DISPLAY ALERTS (If Any) ---
            if active_alerts:
                for alert in active_alerts:
                    # If we have alerts, print them with a warning header
                    print(f" >> [ALERT] {alert['metric_name']} is HIGH: {alert['current_value']}% (Limit: {alert['threshold']}%)")
            
            # --- STEP 5: WAIT ---
            # Wait for the configured time before the next check.
            # We subtract 1 second because psutil.cpu_percent takes 1 second itself.
            sleep_time = max(0, config.MONITOR_INTERVAL - 1)
            time.sleep(sleep_time)

    except KeyboardInterrupt:
        # This block runs if the user presses Ctrl+C
        print("\n[!] Stopping Monitor. Have a great day!")
        sys.exit(0)

# This check ensures the code runs only when we execute this file directly
if __name__ == "__main__":
    start_monitoring()
