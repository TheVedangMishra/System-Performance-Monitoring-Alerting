"""
collector.py

Collects system metrics and inserts them into the PostgreSQL database.
Run this script to start data collection.
"""

import time
import psutil
from datetime import datetime
import db
import config

def collect_and_store():
    conn = db.get_db_connection()
    if not conn:
        print("Failed to connect to DB. Exiting.")
        return

    cursor = conn.cursor()
    print(f"[*] Collector started. Interval: {config.MONITOR_INTERVAL}s")

    try:
        while True:
            # 1. Collect Metrics
            cpu = psutil.cpu_percent(interval=1)
            mem = psutil.virtual_memory().percent
            disk = psutil.disk_usage('/').percent
            timestamp = datetime.now()

            # 2. Insert into Database
            query = """
                INSERT INTO metrics (timestamp, cpu_usage, memory_usage, disk_usage)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (timestamp, cpu, mem, disk))
            conn.commit()

            print(f"[{timestamp}] Inserted -> CPU: {cpu}% | MEM: {mem}% | DISK: {disk}%")

            # 3. Wait
            # Subtract 1s because cpu_percent took 1s
            time.sleep(max(0, config.MONITOR_INTERVAL - 1))

    except KeyboardInterrupt:
        print("\nStopping collector...")
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    collect_and_store()
