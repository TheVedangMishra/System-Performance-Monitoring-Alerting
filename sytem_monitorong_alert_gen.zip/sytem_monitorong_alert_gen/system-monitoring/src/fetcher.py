"""
fetcher.py

Fetches data from the PostgreSQL database for analysis.
"""

import db

def get_latest_metrics():
    """
    Retrieves the most recent row from the metrics table.
    Returns a dictionary or None.
    """
    conn = db.get_db_connection()
    if not conn:
        return None

    try:
        cursor = conn.cursor()
        # Get the single latest record
        query = """
            SELECT cpu_usage, memory_usage, disk_usage, timestamp 
            FROM metrics 
            ORDER BY timestamp DESC 
            LIMIT 1
        """
        cursor.execute(query)
        row = cursor.fetchone()
        
        if row:
            return {
                "cpu": row[0],
                "memory": row[1],
                "disk": row[2],
                "timestamp": row[3]
            }
        return None
    except Exception as e:
        print(f"Error fetching data: {e}")
        return None
    finally:
        conn.close()
