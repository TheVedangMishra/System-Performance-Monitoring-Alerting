# System Monitoring and Alert Generation (Phase 1)

A beginner-friendly Python project to monitor system resources (CPU, Memory, Disk) in real-time and generate alerts when thresholds are exceeded.

## Project Structure
- `src/monitor.py`: Main script to collect data.
- `src/alerts.py`: Logic to check thresholds and create alerts.
- `src/config.py`: Configuration details (thresholds, interval).
- `requirements.txt`: Python dependencies.

## How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the monitor:
   ```bash
   python src/monitor.py
   ```
