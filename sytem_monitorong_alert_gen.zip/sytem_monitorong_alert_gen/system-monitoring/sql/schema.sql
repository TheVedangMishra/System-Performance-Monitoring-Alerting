-- schema.sql
-- Run this in your PostgreSQL database 'system_monitoring'

-- 1. Table for storing raw system metrics (Time-Series Data)
CREATE TABLE IF NOT EXISTS metrics (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cpu_usage FLOAT NOT NULL,
    memory_usage FLOAT NOT NULL,
    disk_usage FLOAT NOT NULL
);

-- 2. Table for storing alert events
CREATE TABLE IF NOT EXISTS alerts (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metric_name VARCHAR(50),
    metric_value FLOAT,
    threshold FLOAT,
    severity VARCHAR(20)
);
